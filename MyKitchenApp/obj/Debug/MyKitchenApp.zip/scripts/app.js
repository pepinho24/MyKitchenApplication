(function (global) {
    
    var app = global.app = global.app || {};
 
    document.addEventListener("deviceready", function () {
        app.application = new kendo.mobile.Application(document.body, { layout: "tabstrip-layout", transition: "slide" });
        
        document.addEventListener("offline", onOffline, false);
        document.addEventListener("volumedownbutton", onVolumeDownKeyDown, false);
        
    }, false);
    var onVolumeDownKeyDown = function onVolumeDownKeyDown()
        {
            alert("Volume Key Down Pressed!");

        }
        var onOffline = function onOffline() {
            alert("Internet connection lost!");
        }
})(window);